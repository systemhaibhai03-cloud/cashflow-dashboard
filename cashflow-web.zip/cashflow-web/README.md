# Cash Flow Dashboard — Web version (GitHub Pages)

Vishal Electricals + Vishal Technopower ka cash flow, Google Sheet se **live**.
Sirf 3 files (`index.html`, `styles.css`, `app.js`) — koi install nahi, koi server nahi.
GitHub Pages pe daalo aur free live link mil jata hai jo phone/laptop kahin bhi khulega.

---

## ⚠️ STEP 0 — Sheet share karo (warna data nahi aayega)

1. Google Sheet kholo → top-right **Share**
2. "General access" → **"Anyone with the link"** → role **Viewer**
3. Done

> Web app browser se data padhta hai, isliye sheet ka link-readable hona zaroori hai.

---

## Step 1 — Local test (optional, par recommended)

Pehle apne PC pe chala kar dekh lo sab sahi hai:

- In teeno files ko ek folder mein rakho
- Browser mein `index.html` ko double-click karke kholo
  - **Agar data aa jaye** → sab sahi, GitHub pe daal do (Step 2)
  - **Agar "Data load nahi hua" aaye** → niche "Agar data na aaye" padho

---

## Step 2 — GitHub Pages pe daalo (free live link)

1. https://github.com pe login/signup karo
2. Top-right **+** → **New repository**
   - Name: `cashflow-dashboard`  ·  **Public**  ·  Create
3. Repo page pe **"uploading an existing file"** link dabao
4. `index.html`, `styles.css`, `app.js` — teeno drag-drop karo → **Commit changes**
5. Upar **Settings** → side mein **Pages**
6. "Build and deployment" → Source: **Deploy from a branch**
   - Branch: **main** · folder: **/ (root)** → **Save**
7. 1–2 min ruko. Page refresh karo — upar link aa jayega:
   `https://<tumhara-username>.github.io/cashflow-dashboard/`

Bas! Wo link kahin se bhi khol sakte ho. 🎉

---

## Data update kaise hoga?

Sheet mein nayi entry add karo → dashboard pe **Refresh data** dabao → naya data aa jayega.
Code dobara upload karne ki zaroorat nahi.

---

## ⚠️ Privacy — ye zaroor samajh lo

- GitHub Pages free ke liye repo **Public** hona padta hai, aur sheet **"Anyone with link"**.
- Matlab jiske paas tumhara Pages link YA sheet link hoga, wo ye data dekh sakta hai.
- Link random aur lamba hai (guess karna mushkil), par financial data hai — link kisi ke
  saath share mat karna.
- Bilkul private chahiye (sirf tumhare PC pe, koi public site nahi) → Electron wali
  desktop version use karo, ya mujhe bolo private setup bana du.

---

## Config (sheet badle to)

`app.js` ke top mein sab settings:
- `SHEET_ID` — sheet ki ID
- `SHEETS` — tab names + company + inflow/outflow
- `INTERCOMPANY` — VE: `TECHNOPOWER`, VTPL: `ELECTRICAL` (transfers exclude)
- `START_DATE` — `new Date(2026, 3, 1)` = 1 April 2026 (month 0-indexed, 3 = April)

---

## Agar data na aaye (CORS)

Bahut kam case mein browser direct fetch block kar sakta hai. Tab:
1. Sheet → **File → Share → Publish to web** → poori sheet publish karo
2. Mujhe bata do — main `app.js` ko published-CSV method pe switch kar dunga (5 min ka kaam).

---

## Features

- **Both / VE / VTPL** — companies alag-alag
- **Monthly / Weekly** filter (1–7, 8–14, 15–21, 22–end)
- **Cash In / Cash Out / Net Flow** (Cr / Lakh)
- **Inter-company transfers auto-excluded** (verify ke liye checkbox)
- **Outflow head-wise**: 1 lakh+ vendor naam se, baaki head-wise
- Row click → **entry-wise detail**
- **1 April 2026 se** data (Feb/March chhuta hua)
